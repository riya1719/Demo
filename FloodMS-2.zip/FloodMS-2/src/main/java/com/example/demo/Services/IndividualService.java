package com.example.demo.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Individual;

@Service
public interface IndividualService {

	Individual addIndividual(Individual individuals);
	
	public List<Individual> getIndividual(); 
}
